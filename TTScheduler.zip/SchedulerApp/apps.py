from django.apps import AppConfig


class SchedulerAppConfig(AppConfig):
    name = 'SchedulerApp'
